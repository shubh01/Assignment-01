package com.inn.shremmontage.rest.impl;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inn.shremmontage.model.Class;
import com.inn.shremmontage.service.IClassService;


@Path("Class")
@Service("ClassRestImpl")
@Consumes("application/json")
@Produces("application/json")
public class ClassRestImpl {
	
	Logger logger=LoggerFactory.getLogger(ClassRestImpl.class);
	
	@Autowired
	private IClassService classObjService;

	@Context
	private SearchContext context;
	
	@POST
	@Path("create")
	public Class create(Class classObj) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method create");
		return classObjService.create(classObj);
	}

	@POST
	@Path("update")
	public Class update(Class classObj) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method update");
		return classObjService.update(classObj);
	}
	
	@POST
	@Path("deleteByPk/{classObjId}")
	public void deleteByPk(@PathParam("classObjId")Integer classObjId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method deleteByPk @param ClassId: "+classObjId);
		classObjService.deleteByPk(classObjId);
	}
	
	@POST
	@Path("findByPk/{classObjId}")
	public Class findByPk(@PathParam("classObjId")Integer classObjId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method findByPk @param ClassId: "+classObjId);
		return classObjService.findByPk(classObjId);
	}
	
	@GET
	@Path("search")
	public List<Class> search(@QueryParam("llimit")Integer lowerLimit,@QueryParam("ulimit")Integer upperLimit)
	{	
		return classObjService.search(context, upperLimit, lowerLimit);
	}
}
