package com.inn.shremmontage.rest.impl;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inn.shremmontage.model.Address;
import com.inn.shremmontage.service.IAddressService;


@Path("Address")
@Service("AddressRestImpl")
@Consumes("application/json")
@Produces("application/json")
public class AddressRestImpl {
	
	Logger logger=LoggerFactory.getLogger(AddressRestImpl.class);
	
	@Autowired
	private IAddressService addressService;

	@Context
	private SearchContext context;
	
	@POST
	@Path("create")
	public Address create(Address address) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method create");
		return addressService.create(address);
	}

	@POST
	@Path("update")
	public Address update(Address address) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method update");
		return addressService.update(address);
	}
	
	@POST
	@Path("deleteByPk/{addressId}")
	public void deleteByPk(@PathParam("addressId")Integer addressId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method deleteByPk @param AddressId: "+addressId);
		addressService.deleteByPk(addressId);
	}
	
	@POST
	@Path("findByPk/{addressId}")
	public Address findByPk(@PathParam("addressId")Integer addressId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method findByPk @param AddressId: "+addressId);
		return addressService.findByPk(addressId);
	}
	
	@GET
	@Path("search")
	public List<Address> search(@QueryParam("llimit")Integer lowerLimit,@QueryParam("ulimit")Integer upperLimit)
	{	
		return addressService.search(context, upperLimit, lowerLimit);
	}

}
