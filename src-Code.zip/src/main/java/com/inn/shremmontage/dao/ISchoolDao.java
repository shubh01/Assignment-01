package com.inn.shremmontage.dao;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;

import com.inn.shremmontage.dao.generic.IGenericDao;
import com.inn.shremmontage.model.School;

public interface ISchoolDao extends IGenericDao<Integer, School>{
}
