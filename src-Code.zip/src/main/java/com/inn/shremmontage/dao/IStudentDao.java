package com.inn.shremmontage.dao;

import com.inn.shremmontage.dao.generic.IGenericDao;
import com.inn.shremmontage.model.Student;

public interface IStudentDao extends IGenericDao<Integer, Student>{

}
