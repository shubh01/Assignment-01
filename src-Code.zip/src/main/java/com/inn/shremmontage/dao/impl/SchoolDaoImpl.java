package com.inn.shremmontage.dao.impl;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inn.shremmontage.dao.ISchoolDao;
import com.inn.shremmontage.dao.generic.HibernateGenericDao;
import com.inn.shremmontage.model.School;
import com.inn.shremmontage.utils.Dao;

@Dao
public class SchoolDaoImpl extends HibernateGenericDao<Integer, School> implements ISchoolDao{

	Logger logger=LoggerFactory.getLogger(SchoolDaoImpl.class);
	
	public SchoolDaoImpl() {
		super(School.class);
	}

	@Override
	public School create(School anEntity) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method create school");
		return super.create(anEntity);
	}

	@Override
	public School update(School anEntity) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method update school");
		return super.update(anEntity);
	}

	@Override
	public void deleteByPk(Integer entityPk) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method deleteByPk school");
		super.deleteByPk(entityPk);
	}

	@Override
	public School findByPk(Integer entityPk) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method findByPk school");
		return super.findByPk(entityPk);
	}

	@Override
	public List<School> findAll() throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method findAll school");
		return super.findAll();
	}

	@Override
	public List<School> search(SearchContext ctx, Integer maxLimit,Integer minLimit) 
	{
		logger.info(this.getClass().getCanonicalName()+" @method search school");
		return super.search(ctx, maxLimit, minLimit);
	}
	
}
