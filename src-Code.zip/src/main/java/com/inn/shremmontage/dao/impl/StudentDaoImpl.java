package com.inn.shremmontage.dao.impl;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inn.shremmontage.dao.IStudentDao;
import com.inn.shremmontage.dao.generic.HibernateGenericDao;
import com.inn.shremmontage.model.Student;
import com.inn.shremmontage.utils.Dao;

@Dao
public class StudentDaoImpl extends HibernateGenericDao<Integer, Student> implements IStudentDao{

	Logger logger=LoggerFactory.getLogger(StudentDaoImpl.class);
	
	public StudentDaoImpl() {
		super(Student.class);
	}

	@Override
	public Student create(Student anEntity) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method create");
		return super.create(anEntity);
	}

	@Override
	public Student update(Student anEntity) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method update");
		return super.update(anEntity);
	}

	@Override
	public void deleteByPk(Integer entityPk) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method deleteByPk");
		super.deleteByPk(entityPk);
	}

	@Override
	public Student findByPk(Integer entityPk) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method findByPk");
		return super.findByPk(entityPk);
	}

	@Override
	public List<Student> findAll() throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method findAll");
		return super.findAll();
	}

	@Override
	public List<Student> search(SearchContext ctx, Integer maxLimit,Integer minLimit) 
	{
		logger.info(this.getClass().getCanonicalName()+" @method search");
		return super.search(ctx, maxLimit, minLimit);
	}
	
}
