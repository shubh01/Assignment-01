package com.inn.shremmontage.dao.generic;

import java.util.List;

import javax.persistence.Entity;

import org.apache.cxf.jaxrs.ext.search.SearchContext;

public interface IGenericDao<Pk,Entity> extends IBaseDao<Pk, Entity>{
	public List<Entity> search(SearchContext ctx, Integer maxLimit,Integer minLimit); 
}
