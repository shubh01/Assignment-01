package com.inn.shremmontage.dao.generic;

import java.util.List;


public interface IBaseDao <PK,Entity>{

	Entity create(Entity anEntity) throws Exception;
	Entity update(Entity anEntity) throws Exception;
	void deleteByPk(PK entityPk) throws Exception;
	Entity findByPk(PK entityPk) throws Exception;
	List<Entity> findAll() throws Exception;
	
}
