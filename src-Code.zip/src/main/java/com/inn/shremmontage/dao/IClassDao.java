package com.inn.shremmontage.dao;

import com.inn.shremmontage.dao.generic.IGenericDao;

public interface IClassDao extends IGenericDao<Integer, com.inn.shremmontage.model.Class>{

}
