package com.inn.shremmontage.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
@javax.persistence.Table(name="class")
public class Class {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id",columnDefinition="INT UNSIGNED")
	private Integer id;
	
	@Column(name="standard")
	private Integer standard;
	
	@OneToOne
	@JoinColumn(name="class_teacher")
	private Teacher teacher;
	
	@OneToMany(mappedBy="classObj")
	private Set<Student> students=new HashSet<Student>();

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getStandard() {
		return standard;
	}

	public void setStandard(Integer standard) {
		this.standard = standard;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

}
