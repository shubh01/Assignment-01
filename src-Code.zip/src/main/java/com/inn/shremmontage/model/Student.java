package com.inn.shremmontage.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.inn.shremmontage.model.Teacher.Gender;

@Entity
@Table(name="student")
public class Student {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Integer id;
	
	@Basic
	@Column(name="name")
	private String name;
	
	@Basic
	@Column(name="age")
	private Integer age;
	
	@Basic
	@Column(name="subject")
	private String subject;
	
	public enum Gender{
		Male,
		Female
	}

	@Column(name="gender")
	@Enumerated(EnumType.STRING)
	private Gender gender;
	
	@OneToOne
	@JoinColumn(name="address_id",columnDefinition="INT UNSIGNED")
	private Address address;

	@OneToOne
	@JoinColumn(name="class_id",columnDefinition="INT UNSIGNED")
	private Class classObj;

	@JsonIgnore
	public Class getClassObj() {
		return classObj;
	}

	public void setClassObj(Class classObj) {
		this.classObj = classObj;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

}
