package com.inn.shremmontage.service;

import com.inn.shremmontage.model.Student;
import com.inn.shremmontage.service.generic.IGenericService;

public interface IStudentService extends IGenericService<Integer,Student>{

}
