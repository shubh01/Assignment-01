package com.inn.shremmontage.service;

import com.inn.shremmontage.model.Address;
import com.inn.shremmontage.service.generic.IGenericService;

public interface IAddressService extends IGenericService<Integer,Address>{

}
