package com.inn.shremmontage.service.generic;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;

public interface IGenericService<Pk,Entity> 
{
	Entity create(Entity anEntity) throws Exception;
	Entity update(Entity anEntity) throws Exception;
	void deleteByPk(Pk entityPk) throws Exception;
	Entity findByPk(Pk entityPk) throws Exception;
	List<Entity> findAll() throws Exception;
	public List<Entity> search(SearchContext ctx, Integer maxLimit,Integer minLimit); 
}
