package com.inn.shremmontage.service.impl;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inn.shremmontage.dao.IClassDao;
import com.inn.shremmontage.model.Class;
import com.inn.shremmontage.service.IClassService;

@Service
@Transactional
public class ClassServiceImpl implements IClassService{

	private IClassDao classDao;
	
	@Autowired
	public void setDao(IClassDao classDaoObj)
	{
		classDao=classDaoObj;
	}
	
	@Override
	public Class create(Class anEntity) throws Exception {
		return classDao.create(anEntity);
	}

	@Override
	public Class update(Class anEntity) throws Exception {
		return classDao.update(anEntity);
	}

	@Override
	public void deleteByPk(Integer entityPk) throws Exception {
		classDao.deleteByPk(entityPk);
		
	}

	@Override
	public Class findByPk(Integer entityPk) throws Exception {
		return classDao.findByPk(entityPk);
	}

	@Override
	public List<Class> findAll() throws Exception {
		return classDao.findAll();
	}

	@Override
	public List<Class> search(SearchContext ctx, Integer maxLimit,
			Integer minLimit) {
		return classDao.search(ctx, maxLimit, minLimit);
	}

	
	
}
