package com.inn.shremmontage.service;

import com.inn.shremmontage.model.School;
import com.inn.shremmontage.service.generic.IGenericService;

public interface ISchoolService extends IGenericService<Integer,School>{

}
