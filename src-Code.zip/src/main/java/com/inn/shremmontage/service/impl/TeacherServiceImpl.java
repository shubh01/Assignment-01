package com.inn.shremmontage.service.impl;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inn.shremmontage.dao.ITeacherDao;
import com.inn.shremmontage.model.Teacher;
import com.inn.shremmontage.service.ITeacherService;

@Service
@Transactional
public class TeacherServiceImpl implements ITeacherService{

	private ITeacherDao teacherDao;
	
	@Autowired
	public void setDao(ITeacherDao teacherDaoObj)
	{
		teacherDao=teacherDaoObj;
	}
	
	@Override
	public Teacher create(Teacher anEntity) throws Exception {
		return teacherDao.create(anEntity);
	}

	@Override
	public Teacher update(Teacher anEntity) throws Exception {
		return teacherDao.update(anEntity);
	}

	@Override
	public void deleteByPk(Integer entityPk) throws Exception {
		teacherDao.deleteByPk(entityPk);
		
	}

	@Override
	public Teacher findByPk(Integer entityPk) throws Exception {
		return teacherDao.findByPk(entityPk);
	}

	@Override
	public List<Teacher> findAll() throws Exception {
		return teacherDao.findAll();
	}

	@Override
	public List<Teacher> search(SearchContext ctx, Integer maxLimit,Integer minLimit) 
	{
		return teacherDao.search(ctx, maxLimit, minLimit);
	}
	
}
