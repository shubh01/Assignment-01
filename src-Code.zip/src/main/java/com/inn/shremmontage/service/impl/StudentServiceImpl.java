package com.inn.shremmontage.service.impl;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inn.shremmontage.dao.IStudentDao;
import com.inn.shremmontage.model.Student;
import com.inn.shremmontage.service.IStudentService;

@Service
@Transactional
public class StudentServiceImpl implements IStudentService{

	private IStudentDao studentDao;
	
	@Autowired
	public void setDao(IStudentDao studentDaoObj)
	{
		studentDao=studentDaoObj;
	}
	
	@Override
	public Student create(Student anEntity) throws Exception {
		return studentDao.create(anEntity);
	}

	@Override
	public Student update(Student anEntity) throws Exception {
		return studentDao.update(anEntity);
	}

	@Override
	public void deleteByPk(Integer entityPk) throws Exception {
		studentDao.deleteByPk(entityPk);
		
	}

	@Override
	public Student findByPk(Integer entityPk) throws Exception {
		return studentDao.findByPk(entityPk);
	}

	@Override
	public List<Student> findAll() throws Exception {
		return studentDao.findAll();
	}

	@Override
	public List<Student> search(SearchContext ctx, Integer maxLimit,
			Integer minLimit) {
		return studentDao.search(ctx, maxLimit, minLimit);
	}

}
