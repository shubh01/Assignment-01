package com.inn.shremmontage.model;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="school")
public class School {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(columnDefinition="INT UNSIGNED")
	private Integer id;

	@Basic
	@Column(name="name")
	private String name;
	
	public enum Type{
		Primary,
		Secondary,
		Higher_Secondary
	}
	
	
	@Basic
	@Column(name="type")
	@Enumerated(EnumType.STRING)
	private Type type;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_id",columnDefinition="INT UNSIGNED")
	private Address address;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
}
