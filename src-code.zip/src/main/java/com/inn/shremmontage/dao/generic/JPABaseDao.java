package com.inn.shremmontage.dao.generic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.slf4j.LoggerFactory;

public class JPABaseDao <PK,Entity> implements IBaseDao<PK, Entity>{

	org.slf4j.Logger logger=LoggerFactory.getLogger(JPABaseDao.class);

	@PersistenceContext(name="DEFAULT",type=PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	private Class<Entity> type;

	public Class<Entity> getType() {
		return type;
	}

	public void setType(Class<Entity> type) {
		this.type = type;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public JPABaseDao(Class<Entity> type){
		this.type=type;
	}

	@Override
	public Entity create(Entity anEntity) throws Exception {
		if(anEntity==null)
			throw new Exception("Null values not allowed in creation");
		return getEntityManager().merge(anEntity);
	}

	@Override
	public Entity update(Entity anEntity) throws Exception {
		if(anEntity==null)
			throw new Exception("Null values not allowed in updation");
		return getEntityManager().merge(anEntity);
	}

	@Override
	public void deleteByPk(PK entityPk) throws Exception {
		if(entityPk==null)
			throw new Exception("Null values not allowed in deletion");
		Entity entity=this.findByPk(entityPk);
		getEntityManager().remove(entity);
		
	}

	@Override
	public Entity findByPk(PK entityPk) throws Exception {
		if(entityPk==null)
			throw new Exception("Null values not allowed in find");
		return getEntityManager().find(getType(), entityPk);
	}

	@Override
	public List<Entity> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}
