package com.inn.shremmontage.dao.impl;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inn.shremmontage.dao.ITeacherDao;
import com.inn.shremmontage.dao.generic.HibernateGenericDao;
import com.inn.shremmontage.model.Teacher;
import com.inn.shremmontage.utils.Dao;

@Dao
public class TeacherDaoImpl extends HibernateGenericDao<Integer, Teacher> implements ITeacherDao{

	Logger logger=LoggerFactory.getLogger(TeacherDaoImpl.class);
	
	public TeacherDaoImpl() {
		super(Teacher.class);
	}

	@Override
	public Teacher create(Teacher anEntity) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method create");
		return super.create(anEntity);
	}

	@Override
	public Teacher update(Teacher anEntity) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method update");
		return super.update(anEntity);
	}

	@Override
	public void deleteByPk(Integer entityPk) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method deleteByPk");
		super.deleteByPk(entityPk);
	}

	@Override
	public Teacher findByPk(Integer entityPk) throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method findByPk");
		return super.findByPk(entityPk);
	}

	@Override
	public List<Teacher> findAll() throws Exception {
		logger.info(this.getClass().getCanonicalName()+" @method findAll");
		return super.findAll();
	}

	@Override
	public List<Teacher> search(SearchContext ctx, Integer maxLimit,Integer minLimit) 
	{
		logger.info(this.getClass().getCanonicalName()+" @method search");
		return super.search(ctx, maxLimit, minLimit);
	}
}
