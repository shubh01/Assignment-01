package com.inn.shremmontage.dao;

import com.inn.shremmontage.dao.generic.IGenericDao;
import com.inn.shremmontage.model.Parents;

public interface IParentsDao extends IGenericDao<Integer, Parents>{

}
