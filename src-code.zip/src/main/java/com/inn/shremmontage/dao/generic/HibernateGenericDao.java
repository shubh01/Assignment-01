package com.inn.shremmontage.dao.generic;

import java.util.List;

import javax.persistence.TypedQuery;

import org.apache.cxf.jaxrs.ext.search.SearchCondition;
import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.apache.cxf.jaxrs.ext.search.jpa.JPATypedQueryVisitor;

public class HibernateGenericDao<Pk,Entity> extends JPABaseDao<Pk, Entity>{

	public HibernateGenericDao(Class<Entity> type) {
		super(type);
	}

	public Entity create(Entity anEntity) throws Exception{
		return super.create(anEntity);
	}

	public Entity update(Entity anEntity) throws Exception{
		return super.update(anEntity);
	}
	
	public void deleteByPk(Pk entityPk) throws Exception{
		super.deleteByPk(entityPk);
	}

	public Entity findByPk(Pk entityPk) throws Exception{
		return super.findByPk(entityPk);
	}

	
	public List<Entity> findAll() throws Exception{
		return super.findAll();
	}
	
	/**
	 * Get search results entity for search condition.
	 * @param sc
	 * @param maxLimit
	 * @param minLimit
	 * @return
	 */
	private List<Entity> getResultsForSearchCondition(SearchCondition<Entity> sc,Integer maxLimit,Integer minLimit) 
	{
		logger.info("HibernateGenericDao-getResultsForSearchCondition start");
		JPATypedQueryVisitor<Entity> visitor = new JPATypedQueryVisitor<Entity>(getEntityManager(), getType());
		sc.accept(visitor);
		visitor.visit(sc);
		TypedQuery<Entity> typedQuery = null;
		typedQuery =visitor.getTypedQuery();
		if (maxLimit >= 0) {
			typedQuery.setMaxResults(maxLimit - minLimit + 1);
		}

		if (minLimit >= 0) {
			typedQuery.setFirstResult(minLimit);
		}
		logger.info("HibernateGenericDao-getResultsForSearchCondition end");
		return typedQuery.getResultList();
	} 
	
	public List<Entity> search(SearchContext ctx, Integer maxLimit,Integer minLimit) 
	{
		logger.info("HibernateGenericDao-search method start With param maxLimit : "+maxLimit+" , minLimit:"+minLimit);
		SearchCondition<Entity> sc = ctx.getCondition(getType());
		return getResultsForSearchCondition(sc,maxLimit,minLimit);
	}
	
}
