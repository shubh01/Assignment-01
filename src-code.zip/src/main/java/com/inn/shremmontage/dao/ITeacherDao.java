package com.inn.shremmontage.dao;

import com.inn.shremmontage.dao.generic.IGenericDao;
import com.inn.shremmontage.model.Teacher;

public interface ITeacherDao extends IGenericDao<Integer, Teacher>{

}
