package com.inn.shremmontage.dao;

import com.inn.shremmontage.dao.generic.IGenericDao;
import com.inn.shremmontage.model.Address;

public interface IAddressDao extends IGenericDao<Integer,Address>{

}
