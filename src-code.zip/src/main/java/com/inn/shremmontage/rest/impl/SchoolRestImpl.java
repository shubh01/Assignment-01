package com.inn.shremmontage.rest.impl;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inn.shremmontage.model.School;
import com.inn.shremmontage.service.ISchoolService;


@Path("School")
@Service("SchoolRestImpl")
@Consumes("application/json")
@Produces("application/json")
public class SchoolRestImpl {
	
	Logger logger=LoggerFactory.getLogger(SchoolRestImpl.class);
	
	@Autowired
	private ISchoolService schoolService;

	@Context
	private SearchContext context;
	
	@POST
	@Path("create")
	public School create(School school) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method create");
		return schoolService.create(school);
	}

	@POST
	@Path("update")
	public School update(School school) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method update");
		return schoolService.update(school);
	}
	
	@POST
	@Path("deleteByPk/{schoolId}")
	public void deleteByPk(@PathParam("schoolId")Integer schoolId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method deleteByPk @param SchoolId: "+schoolId);
		schoolService.deleteByPk(schoolId);
	}
	
	@POST
	@Path("findByPk/{schoolId}")
	public School findByPk(@PathParam("schoolId")Integer schoolId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method findByPk @param SchoolId: "+schoolId);
		return schoolService.findByPk(schoolId);
	}
	
	@GET
	@Path("search")
	public List<School> search(@QueryParam("llimit")Integer lowerLimit,@QueryParam("ulimit")Integer upperLimit)
	{	
		return schoolService.search(context, upperLimit, lowerLimit);
	}
}
