package com.inn.shremmontage.rest.impl;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.search.SearchCondition;
import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inn.shremmontage.model.Teacher;
import com.inn.shremmontage.service.ITeacherService;


@Path("Teacher")
@Service("TeacherRestImpl")
@Consumes("application/json")
@Produces("application/json")
public class TeacherRestImpl {
	
	Logger logger=LoggerFactory.getLogger(TeacherRestImpl.class);
	
	@Autowired
	private ITeacherService teacherService;

	@Context
	private SearchContext context;
	
	private List<Teacher> teachers;

	@POST
	@Path("create")
	public Teacher create(Teacher teacher) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method create");
		return teacherService.create(teacher);
	}

	@POST
	@Path("update")
	public Teacher update(Teacher teacher) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method update");
		return teacherService.update(teacher);
	}
	
	@POST
	@Path("deleteByPk/{teacherId}")
	public void deleteByPk(@PathParam("teacherId")Integer teacherId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method deleteByPk @param teacherId: "+teacherId);
		teacherService.deleteByPk(teacherId);
	}
	
	@POST
	@Path("findByPk/{teacherId}")
	public Teacher findByPk(@PathParam("teacherId")Integer teacherId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method findByPk @param teacherId: "+teacherId);
		return teacherService.findByPk(teacherId);
	}
	
	@GET
	@Path("search")
	public List<Teacher> search()
	{
		System.out.println(" inside search: searchContext: "+context);
		SearchCondition<Teacher> searchCondition=context.getCondition(Teacher.class);	
		return searchCondition.findAll(teachers);
	}
}
