package com.inn.shremmontage.rest.impl;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inn.shremmontage.model.Student;
import com.inn.shremmontage.service.IStudentService;


@Path("Student")
@Service("StudentRestImpl")
@Consumes("application/json")
@Produces("application/json")
public class StudentRestImpl {

	Logger logger=LoggerFactory.getLogger(StudentRestImpl.class);
	
	@Autowired
	private IStudentService studentService;

	@Context
	private SearchContext context;
	
	@POST
	@Path("create")
	public Student create(Student student) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method create");
		return studentService.create(student);
	}

	@POST
	@Path("update")
	public Student update(Student student) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method update");
		return studentService.update(student);
	}
	
	@POST
	@Path("deleteByPk/{studentId}")
	public void deleteByPk(@PathParam("studentId")Integer studentId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method deleteByPk @param StudentId: "+studentId);
		studentService.deleteByPk(studentId);
	}
	
	@POST
	@Path("findByPk/{studentId}")
	public Student findByPk(@PathParam("studentId")Integer studentId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method findByPk @param StudentId: "+studentId);
		return studentService.findByPk(studentId);
	}
	
	@GET
	@Path("search")
	public List<Student> search(@QueryParam("llimit")Integer lowerLimit,@QueryParam("ulimit")Integer upperLimit)
	{	
		return studentService.search(context, upperLimit, lowerLimit);
	}

	
}
