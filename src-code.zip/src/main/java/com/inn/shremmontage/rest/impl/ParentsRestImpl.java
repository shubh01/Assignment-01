package com.inn.shremmontage.rest.impl;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inn.shremmontage.model.Parents;
import com.inn.shremmontage.service.IParentsService;


@Path("Parents")
@Service("ParentsRestImpl")
@Consumes("application/json")
@Produces("application/json")
public class ParentsRestImpl {

	Logger logger=LoggerFactory.getLogger(ParentsRestImpl.class);
	
	@Autowired
	private IParentsService parentsService;

	@Context
	private SearchContext context;
	
	@POST
	@Path("create")
	public Parents create(Parents parents) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method create");
		return parentsService.create(parents);
	}

	@POST
	@Path("update")
	public Parents update(Parents parents) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method update");
		return parentsService.update(parents);
	}
	
	@POST
	@Path("deleteByPk/{parentsId}")
	public void deleteByPk(@PathParam("parentsId")Integer parentsId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method deleteByPk @param ParentsId: "+parentsId);
		parentsService.deleteByPk(parentsId);
	}
	
	@POST
	@Path("findByPk/{parentsId}")
	public Parents findByPk(@PathParam("parentsId")Integer parentsId) throws Exception
	{
		logger.info(this.getClass().getCanonicalName()+" @method findByPk @param ParentsId: "+parentsId);
		return parentsService.findByPk(parentsId);
	}
	
	@GET
	@Path("search")
	public List<Parents> search(@QueryParam("llimit")Integer lowerLimit,@QueryParam("ulimit")Integer upperLimit)
	{	
		return parentsService.search(context, upperLimit, lowerLimit);
	}

	
}
