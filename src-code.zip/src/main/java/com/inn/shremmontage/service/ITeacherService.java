package com.inn.shremmontage.service;

import com.inn.shremmontage.model.Teacher;
import com.inn.shremmontage.service.generic.IGenericService;

public interface ITeacherService extends IGenericService<Integer,Teacher>{

}
