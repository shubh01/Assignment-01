package com.inn.shremmontage.service;

import com.inn.shremmontage.model.Class;
import com.inn.shremmontage.service.generic.IGenericService;

public interface IClassService extends IGenericService<Integer,Class>{

}
