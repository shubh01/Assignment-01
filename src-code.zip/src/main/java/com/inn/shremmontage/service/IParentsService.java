package com.inn.shremmontage.service;

import com.inn.shremmontage.model.Parents;
import com.inn.shremmontage.service.generic.IGenericService;

public interface IParentsService extends IGenericService<Integer,Parents>{

}
