package com.inn.shremmontage.service.impl;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inn.shremmontage.dao.IParentsDao;
import com.inn.shremmontage.model.Parents;
import com.inn.shremmontage.service.IParentsService;

@Service
@Transactional
public class ParentsServiceImpl implements IParentsService{

	private IParentsDao parentsDao;
	
	@Autowired
	public void setDao(IParentsDao parentsDaoObj)
	{
		parentsDao=parentsDaoObj;
	}
	
	@Override
	public Parents create(Parents anEntity) throws Exception {
		return parentsDao.create(anEntity);
	}

	@Override
	public Parents update(Parents anEntity) throws Exception {
		return parentsDao.update(anEntity);
	}

	@Override
	public void deleteByPk(Integer entityPk) throws Exception {
		parentsDao.deleteByPk(entityPk);
		
	}

	@Override
	public Parents findByPk(Integer entityPk) throws Exception {
		return parentsDao.findByPk(entityPk);
	}

	@Override
	public List<Parents> findAll() throws Exception {
		return parentsDao.findAll();
	}

	@Override
	public List<Parents> search(SearchContext ctx, Integer maxLimit,
			Integer minLimit) {
		return parentsDao.search(ctx, maxLimit, minLimit);
	}

}
