package com.inn.shremmontage.service.impl;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inn.shremmontage.dao.ISchoolDao;
import com.inn.shremmontage.model.School;
import com.inn.shremmontage.service.ISchoolService;

@Service
@Transactional
public class SchoolServiceImpl implements ISchoolService{

	private ISchoolDao schoolDao;
	
	@Autowired
	public void setDao(ISchoolDao schoolDaoObj)
	{
		schoolDao=schoolDaoObj;
	}
	
	@Override
	public School create(School anEntity) throws Exception {
		return schoolDao.create(anEntity);
	}

	@Override
	public School update(School anEntity) throws Exception {
		return schoolDao.update(anEntity);
	}

	@Override
	public void deleteByPk(Integer entityPk) throws Exception {
		schoolDao.deleteByPk(entityPk);
		
	}

	@Override
	public School findByPk(Integer entityPk) throws Exception {
		return schoolDao.findByPk(entityPk);
	}

	@Override
	public List<School> findAll() throws Exception {
		return schoolDao.findAll();
	}

	@Override
	public List<School> search(SearchContext ctx, Integer maxLimit,Integer minLimit) 
	{
		return schoolDao.search(ctx, maxLimit, minLimit);
	}
	
}
