package com.inn.shremmontage.service.impl;

import java.util.List;

import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inn.shremmontage.dao.IAddressDao;
import com.inn.shremmontage.model.Address;
import com.inn.shremmontage.service.IAddressService;

@Service
@Transactional
public class AddressServiceImpl implements IAddressService{

	private IAddressDao addressDao;
	
	@Autowired
	public void setDao(IAddressDao addrressDaoObj)
	{
		addressDao=addrressDaoObj;
	}
	
	@Override
	public Address create(Address anEntity) throws Exception {
		return addressDao.create(anEntity);
	}

	@Override
	public Address update(Address anEntity) throws Exception {
		return addressDao.update(anEntity);
	}

	@Override
	public void deleteByPk(Integer entityPk) throws Exception {
		addressDao.deleteByPk(entityPk);
		
	}

	@Override
	public Address findByPk(Integer entityPk) throws Exception {
		return addressDao.findByPk(entityPk);
	}

	@Override
	public List<Address> findAll() throws Exception {
		return addressDao.findAll();
	}

	@Override
	public List<Address> search(SearchContext ctx, Integer maxLimit,
			Integer minLimit) {
		return addressDao.search(ctx, maxLimit, minLimit);
	}

	
	
}
